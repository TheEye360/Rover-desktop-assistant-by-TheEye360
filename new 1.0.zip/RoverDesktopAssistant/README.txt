Move Gif Files and Ico Files on C:\
to program works correctly!